TW.IDE.Widgets.series_line_chart1 = function () {

    this.widgetIconUrl = function () {
        return "../Common/extensions/SeriesLineChart_ExtensionPackage/ui/series_line_chart1/series.png";
    };

    this.widgetProperties = function () {
        return {
            'name' : 'Series Line Chart1',
            'description' : '',
            'category' : [ 'Common' ],
            'supportsAutoResize' : true,// 自适应宽高
            'defaultBindingTargetProperty' : 'Data',
            'properties' : {
                'Data' : {
                    'description' : 'Data source',
                    'isBindingTarget' : true,
                    'isEditable' : false,
                    'baseType' : 'INFOTABLE',
                    'warnIfNotBoundAsTarget' : true
                },
                'xAxisField' : {
                    'description' : 'x轴',
                    'baseType' : 'FIELDNAME',
                    'sourcePropertyName' : 'Data',
                    'isBindingTarget' : false,
                    'baseTypeRestriction' : 'DATETIME',
                    'isVisible' : true,
                    'warnIfNotBoundAsTarget' : true
                },
                'dataFied' : {
                    'description' : 'y轴',
                    'baseType' : 'FIELDNAME',
                    'sourcePropertyName' : 'Data',
                    'isBindingTarget' : false,
                    'baseTypeRestriction' : 'STRING',
                    'isVisible' : true,
                },
                'Style1' : {
                    'description' : '线条样式1',
                    'defaultValue' : {
                        image : "",
                        backgroundColor : "#E5D947",
                        foregroundColor : "",
                        fontEmphasisBold : false,
                        fontEmphasisItalic : false,
                        fontEmphasisUnderline : false,
                        displayString : "",
                        lineThickness : 1,
                        lineStyle : "solid",
                        lineColor : "",
                        secondaryBackgroundColor : "",
                        textSize : 'normal'
                    },
                    'baseType' : 'STYLEDEFINITION',
                },
                'Style2' : {
                    'description' : '线条样式2',
                    'defaultValue' : {
                        image : "",
                        backgroundColor : "#5DCCF8",
                        foregroundColor : "",
                        fontEmphasisBold : false,
                        fontEmphasisItalic : false,
                        fontEmphasisUnderline : false,
                        displayString : "",
                        lineThickness : 1,
                        lineStyle : "solid",
                        lineColor : "",
                        secondaryBackgroundColor : "",
                        textSize : 'normal'
                    },
                    'baseType' : 'STYLEDEFINITION',
                },
                'Style3' : {
                    'description' : '线条样式3',
                    'defaultValue' : {
                        image : "",
                        backgroundColor : "#FF6161",
                        foregroundColor : "",
                        fontEmphasisBold : false,
                        fontEmphasisItalic : false,
                        fontEmphasisUnderline : false,
                        displayString : "",
                        lineThickness : 1,
                        lineStyle : "solid",
                        lineColor : "",
                        secondaryBackgroundColor : "",
                        textSize : 'normal'
                    },
                    'baseType' : 'STYLEDEFINITION',
                },
                'Style4' : {
                    'description' : '线条样式4',
                    'defaultValue' : {
                        image : "",
                        backgroundColor : "#0CBCA7",
                        foregroundColor : "",
                        fontEmphasisBold : false,
                        fontEmphasisItalic : false,
                        fontEmphasisUnderline : false,
                        displayString : "",
                        lineThickness : 1,
                        lineStyle : "solid",
                        lineColor : "",
                        secondaryBackgroundColor : "",
                        textSize : 'normal'
                    },
                    'baseType' : 'STYLEDEFINITION',
                },
                'Label1' : {
                    'description' : '下限',
                    'baseType' : 'STRING',
                    'defaultValue' : "下限",
                    'isBindingTarget' : true
                },
                'Label2' : {
                    'description' : '中心值',
                    'baseType' : 'STRING',
                    'defaultValue' : "中心值",
                    'isBindingTarget' : true
                },
                'Label3' : {
                    'description' : '上限',
                    'baseType' : 'STRING',
                    'defaultValue' : "上限",
                    'isBindingTarget' : true
                },
                'Label4' : {
                    'description' : '属性值',
                    'baseType' : 'STRING',
                    'defaultValue' : "属性值",
                    'isBindingTarget' : true
                },
                'min' : {
                    'description' : '下限',
                    'baseType' : 'NUMBER',
                    'isBindingTarget' : true,
                    'isVisible' : true
                },
                'average' : {
                    'description' : '中心值',
                    'baseType' : 'NUMBER',
                    'isBindingTarget' : true,
                    'isVisible' : true
                },
                'max' : {
                    'description' : '上限',
                    'baseType' : 'NUMBER',
                    'isBindingTarget' : true,
                    'isVisible' : true
                },
            }
        }
    };

    this.afterSetProperty = function (name, value) {
        var thisWidget = this;
        var refreshHtml = false;
        switch (name) {
        case 'Style':
        case 'Series Line Chart Property':
            thisWidget.jqElement.find('.series-line-chart-property')
                    .text(value);
        case 'Alignment':
            refreshHtml = true;
            break;
        default:
            break;
        }
        return refreshHtml;
    };

    this.renderHtml = function () {

        return '<div class="widget-content widget-series_line_chart1">'
                + '<span class="series-line-chart-property">多折线</span>'
                + '</div>';
    };

    this.afterRender = function () {

    };

};