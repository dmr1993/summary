TW.Runtime.Widgets.series_line_chart1 = function () {
    var valueElem;
    var thisWidget = this;

    thisWidget.id = thisWidget.getProperty('Id');
    thisWidget.xAxisField = thisWidget.getProperty('xAxisField');
    thisWidget.dataFied = thisWidget.getProperty('dataFied');

    var label1 = thisWidget.getProperty('Label1');
    var label2 = thisWidget.getProperty('Label2');
    var label3 = thisWidget.getProperty('Label3');
    var label4 = thisWidget.getProperty('Label4');

    thisWidget.Style1 = thisWidget.getProperty('Style1');
    thisWidget.Style2 = thisWidget.getProperty('Style2');
    thisWidget.Style3 = thisWidget.getProperty('Style3');
    thisWidget.Style4 = thisWidget.getProperty('Style4');

    var color1 = TW.getStyleFromStyleDefinition(thisWidget.Style1, 'Style1').backgroundColor;
    var color2 = TW.getStyleFromStyleDefinition(thisWidget.Style2, 'Style2').backgroundColor;
    var color3 = TW.getStyleFromStyleDefinition(thisWidget.Style3, 'Style3').backgroundColor;
    var color4 = TW.getStyleFromStyleDefinition(thisWidget.Style4, 'Style4').backgroundColor;

    var xAxis = [], series1 = [], series2 = [], series3 = [], series4 = [];

    this.renderHtml = function () {
        $('head')
                .append(
                        '<script>'
                                + 'window.defineBackup = window.define;'
                                + 'window.define = undefined;'
                                + '</script>'
                                + '<script type="text/javascript" src="../Common/extensions/SeriesLineChart_ExtensionPackage/ui/series_line_chart1/echarts.min.js"></script>'
                                + '<script>'
                                + 'window.define = window.defineBackup;'
                                + '</script>');
        return '<div class="widget-content widget-series_line_chart1">'
                + '<div id="'
                + thisWidget.id
                + '" style="height:calc(100% - 10px);width:calc(100% - 10px);"></div>'
                + '</div>';
    };

    function renderChart() {
        var myChart = echarts.init(document.getElementById(thisWidget.id));
        var option = {
            tooltip : {
                show : true,
                trigger : "axis",
                axisPointer : {
                    animation : false,
                },
            },
            grid : {
                show : false,
                left : 40,
                right : 20,
                top : 40,
                bottom : 32
            },
            legend : {
                show : true,
                selectedMode : false,
                textStyle : {},
            },
            xAxis : {
                axisTick : {
                    show : true,
                    alignWithLabel : true
                },
                nameStyle : {
                    fontSize : 10,
                },
                axisLabel : {
                    show : true,
                    fontSize : 10,
                },
                splitLine : {
                    show : false,
                },
                axisLine : {
                    show : true,
                    lineStyle : {},
                    axisTick : {
                        show : false,
                    },
                },
                data : xAxis,
            },
            yAxis : {
                axisTick : {
                    show : true,
                    lineStyle : {
                        color : "black"
                    }
                },
                type : "value",
                boundaryGap : [ 0, "20%" ],
                axisLabel : {},
                axisLine : {
                    show : true,
                    lineStyle : {},
                    axisTick : {
                        show : false,
                    },
                },
                splitLine : {
                    show : false,
                    lineStyle : {},
                },
            },
            series : [ {
                data : series1,
                name : label1,
                symbolSize : 0.01,
                color : color1,
                type : "line",
                smooth : false,
                label : {
                    show : true,
                    position : "right",
                    fontSize : 10,
                    formatter : function (params) {
                        var dataIndex = params.dataIndex;
                        var value = params.value;
                        var seriesIndex = params.seriesIndex;
                        var res;
                        if (dataIndex == (series4.length - 1)) {
                            res = value[1];
                        } else {
                            res = "";
                        }
                        return res;
                    },
                },
            }, {
                data : series2,
                name : label2,
                color : color2,
                type : "line",
                smooth : false,
                symbolSize : 0.01,
                label : {
                    normal : {
                        show : true,
                        position : "right",
                        fontSize : 10,
                        formatter : function (params) {
                            var dataIndex = params.dataIndex;
                            var value = params.value;
                            var seriesIndex = params.seriesIndex;
                            var res;
                            if (dataIndex == (series4.length - 1)) {
                                res = value[1];
                            } else {
                                res = "";
                            }
                            return res;
                        },
                    },
                },
            }, {
                data : series3,
                name : label3,
                color : color3,
                type : "line",
                smooth : false,
                symbolSize : 0.01,
                label : {
                    show : true,
                    position : "right",
                    fontSize : 10,
                    formatter : function (params) {
                        var dataIndex = params.dataIndex;
                        var value = params.value;
                        var seriesIndex = params.seriesIndex;
                        var res;
                        if (dataIndex == (series4.length - 1)) {
                            res = value[1];
                        } else {
                            res = "";
                        }
                        return res;
                    },
                },
            }, {
                data : series4,
                name : label4,
                color : color4,
                type : "line",
                smooth : false,
                symbolSize : 0.01,
                label : {
                    normal : {
                        show : false,
                    },
                },
            }, ],
        };
        myChart.setOption(option);
    }

    this.afterRender = function () {
        if (this.properties.ResponsiveLayout) {
            var that = this;
            // 等到页面加载完成获取高度
            var timer = setTimeout(function () {
                var width = that.jqElement.width();
                var height = that.jqElement.height()
                var canvas = document.getElementById(thisWidget.id);
                canvas.style.width = width - 10 + 'px';
                canvas.style.height = height - 10 + 'px';
                renderChart();
                clearTimeout(timer);
                timer = null;
            }, 0)
        }
    };

    this.updateProperty = function (updatePropertyInfo) {

        if (updatePropertyInfo.TargetProperty === 'min') {
            series1 = [];
            this.setProperty('min',
                    Number(updatePropertyInfo.SinglePropertyValue));
            for (var i = 0; i < series4.length; i++) {
                series1.push([ series4[i][0],
                        Number(updatePropertyInfo.SinglePropertyValue) ])
            }
            renderChart();
        }
        if (updatePropertyInfo.TargetProperty === 'average') {

            this.setProperty('average',
                    Number(updatePropertyInfo.SinglePropertyValue));
            series2 = [];
            for (var i = 0; i < series4.length; i++) {
                series2.push([ series4[i][0],
                        Number(updatePropertyInfo.SinglePropertyValue) ])
            }
            renderChart();
        }
        if (updatePropertyInfo.TargetProperty === 'max') {
            series3 = []
            this.setProperty('max',
                    Number(updatePropertyInfo.SinglePropertyValue));
            for (var i = 0; i < series4.length; i++) {
                series3.push([ series4[i][0],
                        Number(updatePropertyInfo.SinglePropertyValue) ])
            }
            renderChart();
        }

        // Label
        if (updatePropertyInfo.TargetProperty === 'Label1') {
            label1 = updatePropertyInfo.SinglePropertyValue
            this.setProperty('Label1', label1);
            renderChart();
        }
        if (updatePropertyInfo.TargetProperty === 'Label2') {
            label2 = updatePropertyInfo.SinglePropertyValue
            this.setProperty('Label2', label2);
            renderChart();
        }
        if (updatePropertyInfo.TargetProperty === 'Label3') {
            label3 = updatePropertyInfo.SinglePropertyValue
            this.setProperty('Label3', label3);
            renderChart();
        }
        if (updatePropertyInfo.TargetProperty === 'Label4') {
            label4 = updatePropertyInfo.SinglePropertyValue
            this.setProperty('Label4', label4);
            renderChart();
        }

        // DATA
        if (updatePropertyInfo.TargetProperty === 'Data') {

            xAxis = [];
            series1 = [];
            series2 = [];
            series3 = [];
            series4 = [];

            var currentDataInfo = updatePropertyInfo;

            var currentRows = currentDataInfo.ActualDataRows;

            var row;

            var x, y;

            for (var i = 0; i < currentRows.length; i++) {

                row = currentRows[i];

                x = row[thisWidget.xAxisField];

                y = row[thisWidget.dataFied];

                xAxis.push(x)

                series1.push([ x, thisWidget.getProperty('min') ]);
                series2.push([ x, thisWidget.getProperty('average') ]);
                series3.push([ x, thisWidget.getProperty('max') ]);
                series4.push([ x, y ]);
                
            }
            renderChart();

        }
    };
};