TW.IDE.Widgets.series_line_chart1 = function () {

    this.widgetIconUrl = function () {
        return "../Common/extensions/SeriesLineChart_ExtensionPackage/ui/series_line_chart1/series.png";
    };

    this.widgetProperties = function () {
        return {
            'name' : 'Series Line Chart1',
            'description' : '',
            'category' : [ 'Common' ],
            'supportsAutoResize' : true,// 自适应宽高
            'properties' : {
                'Style1' : {
                    'description' : '线条样式1',
                    'defaultValue' : {
                        image : "",
                        backgroundColor : "#A0FFB1",
                        foregroundColor : "",
                        fontEmphasisBold : false,
                        fontEmphasisItalic : false,
                        fontEmphasisUnderline : false,
                        displayString : "",
                        lineThickness : 1,
                        lineStyle : "solid",
                        lineColor : "",
                        secondaryBackgroundColor : "",
                        textSize : 'normal'
                    },
                    'baseType' : 'STYLEDEFINITION',
                },
                'Style2' : {
                    'description' : '线条样式2',
                    'defaultValue' : {
                        image : "",
                        backgroundColor : "#6DB5FF",
                        foregroundColor : "",
                        fontEmphasisBold : false,
                        fontEmphasisItalic : false,
                        fontEmphasisUnderline : false,
                        displayString : "",
                        lineThickness : 1,
                        lineStyle : "solid",
                        lineColor : "",
                        secondaryBackgroundColor : "",
                        textSize : 'normal'
                    },
                    'baseType' : 'STYLEDEFINITION',
                },
                'Style3' : {
                    'description' : '线条样式3',
                    'defaultValue' : {
                        image : "",
                        backgroundColor : "#FF6161",
                        foregroundColor : "",
                        fontEmphasisBold : false,
                        fontEmphasisItalic : false,
                        fontEmphasisUnderline : false,
                        displayString : "",
                        lineThickness : 1,
                        lineStyle : "solid",
                        lineColor : "",
                        secondaryBackgroundColor : "",
                        textSize : 'normal'
                    },
                    'baseType' : 'STYLEDEFINITION',
                },
                'Label1' : {
                    'description' : '标签一',
                    'baseType' : 'STRING',
                    'defaultValue' : "标签一",
                    'isBindingTarget' : true
                },
                'Label2' : {
                    'description' : '标签二',
                    'baseType' : 'STRING',
                    'defaultValue' : "标签二",
                    'isBindingTarget' : true
                },
                'Label3' : {
                    'description' : '标签三',
                    'baseType' : 'STRING',
                    'defaultValue' : "标签三",
                    'isBindingTarget' : true
                },
                'min' : {
                    'description' : '最小值',
                    'baseType' : 'NUMBER',
                    'isBindingTarget' : true,
                    'isVisible' : true
                },
                'average' : {
                    'description' : '平均值',
                    'baseType' : 'NUMBER',
                    'isBindingTarget' : true,
                    'isVisible' : true
                },
                'max' : {
                    'description' : '最大值',
                    'baseType' : 'NUMBER',
                    'isBindingTarget' : true,
                    'isVisible' : true
                },
            }
        }
    };

    this.afterSetProperty = function (name, value) {
        var thisWidget = this;
        var refreshHtml = false;
        switch (name) {
        case 'Style':
        case 'Series Line Chart Property':
            thisWidget.jqElement.find('.series-line-chart-property')
                    .text(value);
        case 'Alignment':
            refreshHtml = true;
            break;
        default:
            break;
        }
        return refreshHtml;
    };

    this.renderHtml = function () {
        // return any HTML you want rendered for your widget
        // If you want it to change depending on properties that the user
        // has set, you can use this.getProperty(propertyName).
        return '<div class="widget-content widget-series_line_chart1">'
                + '<span class="series-line-chart-property">多折线</span>'
                + '</div>';
    };

    this.afterRender = function () {
        // NOTE: this.jqElement is the jquery reference to your html dom element
        // that was returned in renderHtml()

        // get a reference to the value element
        valueElem = this.jqElement.find('.series-line-chart-property');
        // update that DOM element based on the property value that the user set
        // in the mashup builder
        valueElem.text(this.getProperty('Series Line Chart Property'));
    };

};