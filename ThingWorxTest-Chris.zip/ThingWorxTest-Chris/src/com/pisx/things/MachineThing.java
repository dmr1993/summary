package com.pisx.things;
import java.util.Random;


import com.thingworx.communications.client.ConnectedThingClient;
import com.thingworx.communications.client.things.VirtualThing;
import com.thingworx.metadata.annotations.ThingworxPropertyDefinition;
import com.thingworx.metadata.annotations.ThingworxPropertyDefinitions;
import com.thingworx.metadata.annotations.ThingworxServiceDefinition;
import com.thingworx.metadata.annotations.ThingworxServiceParameter;
import com.thingworx.metadata.annotations.ThingworxServiceResult;
import com.thingworx.system.subsystems.filetransfer.FileTransferSubsystem;
import com.thingworx.types.InfoTable;
import com.thingworx.types.collections.ValueCollection;
import com.thingworx.types.constants.CommonPropertyNames;

//Refer to the "Steam Sensor Example" section of the documentation
//for a detailed explanation of this example's operation 

// Property Definitions
@SuppressWarnings("serial")
@ThingworxPropertyDefinitions(properties = {
		@ThingworxPropertyDefinition(name="温度", description="温度", baseType="NUMBER", category="Status", aspects={"isReadOnly:true"}),
		@ThingworxPropertyDefinition(name="电流", description="电流", baseType="NUMBER", category="Status", aspects={"isReadOnly:true"}),
	})

// Event Definitions
/*@ThingworxEventDefinitions(events = {
	@ThingworxEventDefinition(name="SteamSensorFault", description="Steam sensor fault", dataShape="SteamSensor.Fault", category="Faults", isInvocable=true, isPropertyEvent=false)
})*/

// Steam Thing virtual thing class that simulates a Steam Sensor
public class MachineThing extends VirtualThing implements Runnable {
	
	//private double _totalFlow = 0.0;
	private Thread _shutdownThread = null;
	
	public MachineThing(String name, String description, String identifier, ConnectedThingClient client) {
		super(name,description,identifier,client);
		
		// Data Shape definition that is used by the steam sensor fault event
		// The event only has one field, the message
		/*FieldDefinitionCollection faultFields = new FieldDefinitionCollection();
		faultFields.addFieldDefinition(new FieldDefinition(CommonPropertyNames.PROP_MESSAGE,BaseTypes.STRING));
		defineDataShapeDefinition("SteamSensor.Fault", faultFields);*/

		// Populate the thing shape with the properties, services, and events that are annotated in this code
		super.initializeFromAnnotations();
	}

	// From the VirtualThing class
	// This method will get called when a connect or reconnect happens
	// Need to send the values when this happens
	// This is more important for a solution that does not send its properties on a regular basis
	public void synchronizeState() {
		// Be sure to call the base class
		super.synchronizeState();
		// Send the property values to Thingworx when a synchronization is required
		super.syncProperties();
	}
	
	// The processScanRequest is called by the SteamSensorClient every scan cycle
	@Override
	public void processScanRequest() throws Exception {
		// Be sure to call the base classes scan request
		super.processScanRequest();
		// Execute the code for this simulation every scan
		this.scanDevice();
	}
	
	// Performs the logic for the steam sensor, occurs every scan cycle
	public void scanDevice() throws Exception {
		// Set the Temperature property value in the range of 400-440
		Random rand = new Random();
		int prop1 = rand.nextInt(); 
		prop1 = 100 + rand.nextInt(100); 
		int prop2 = rand.nextInt(); 
		prop2 = 100 + rand.nextInt(100);
		
		// Set the property values
		super.setProperty("温度", prop1);
		super.setProperty("电流", prop2);
		
		// Update the subscribed properties and events to send any updates to Thingworx
		// Without calling these methods, the property and event updates will not be sent
		// The numbers are timeouts in milliseconds.
		super.updateSubscribedProperties(15000);
		super.updateSubscribedEvents(60000);
	}
	
	/*@ThingworxServiceDefinition( name="AddNumbers", description="Add Two Numbers")
	@ThingworxServiceResult( name=CommonPropertyNames.PROP_RESULT, description="Result", baseType="NUMBER" )
	public Double AddNumbers( 
			@ThingworxServiceParameter( name="a", description="Value 1", baseType="NUMBER" ) Double a,
			@ThingworxServiceParameter( name="b", description="Value 2", baseType="NUMBER" ) Double b) throws Exception {
		
		return a + b;
	}

	@ThingworxServiceDefinition( name="GetBigString", description="Get big string")
	@ThingworxServiceResult( name=CommonPropertyNames.PROP_RESULT, description="Result", baseType="STRING" )
	public String GetBigString() {
		StringBuilder sbValue = new StringBuilder();
		
		for(int i=0;i<24000;i++) {
			sbValue.append('0');
		}
		
		return sbValue.toString();
	}*/
	
	@ThingworxServiceDefinition(name="TransferToAsset", description="Transfers one or more files from the platform file repository to the device virtual directory.")
	  @ThingworxServiceResult(name="result", description="Indicates whether the transfer was initiated.", baseType="STRING")
	  public String TransferToDevice(@ThingworxServiceParameter(name="targetPath", description="Directory path in the asset virtual directory", baseType="STRING", aspects={"isRequired:true"}) String targetPath, @ThingworxServiceParameter(name="targetRepo", description="Repository name on the asset", baseType="STRING", aspects={"isRequired:true"}) String targetRepo, @ThingworxServiceParameter(name="sourcePath", description="Directory path in the platform repository", baseType="STRING", aspects={"isRequired:true"}) String sourcePath, @ThingworxServiceParameter(name="sourceRepo", description="Repository name on the platform", baseType="STRING", aspects={"isRequired:true"}) String sourceRepo, @ThingworxServiceParameter(name="sourceFiles", description="Files to be transfered", baseType="INFOTABLE", aspects={"isRequired:true", "dataShape:TW.RSM.AssetProperties", "isMultiRow:true"}) InfoTable sourceFiles)
	    throws Exception{
	    return transferFiles(targetPath, targetRepo, sourcePath, sourceRepo, sourceFiles);
	  }

	  @ThingworxServiceDefinition(name="TransferFromAsset", description="Transfers one or more files from the device virtual directory to the platform file repository.")
	  @ThingworxServiceResult(name="result", description="Indicates whether the transfer was initiated.", baseType="STRING")
	  public String TransferFromDevice(@ThingworxServiceParameter(name="targetPath", description="Directory path in the platform repository", baseType="STRING", aspects={"isRequired:true"}) String targetPath, @ThingworxServiceParameter(name="targetRepo", description="Repository name on the platform", baseType="STRING", aspects={"isRequired:true"}) String targetRepo, @ThingworxServiceParameter(name="sourcePath", description="Directory path in the asset virtual directory", baseType="STRING", aspects={"isRequired:true"}) String sourcePath, @ThingworxServiceParameter(name="sourceRepo", description="Repository name on the asset", baseType="STRING", aspects={"isRequired:true"}) String sourceRepo, @ThingworxServiceParameter(name="sourceFiles", description="Files to be transfered", baseType="INFOTABLE", aspects={"isRequired:true", "dataShape:TW.RSM.AssetProperties", "isMultiRow:true"}) InfoTable sourceFiles)
	    throws Exception{
	    return transferFiles(targetPath, targetRepo, sourcePath, sourceRepo, sourceFiles);
	  }
	
	private String transferFiles(String targetPath, String targetRepo, String sourcePath, String sourceRepo, InfoTable sourceFiles) 
			throws Exception{
		int tableLength = sourceFiles.getRowCount().intValue();
	    String result = "Transfer Initiated";

	    for (int rowIndex = 0; rowIndex < tableLength; ++rowIndex) {
	    	ValueCollection row = sourceFiles.getRow(rowIndex);
	    	String fileName = row.getStringValue("name");
	    	FileTransferSubsystem fileTransferSubsystem = FileTransferSubsystem.getSubsystemInstance();
	    	InfoTable copyResponse = fileTransferSubsystem.Copy(sourceRepo, sourcePath, fileName, targetRepo, targetPath, 
	    			null, null, Boolean.valueOf(true));
	    	String copyResponseMessage = copyResponse.getRow(0).getStringValue("message");
	    	if (copyResponseMessage.contains("error")){
		        result = "An error occurred during transfer";
	    	}
	    }
	    return result;
	}

	@ThingworxServiceDefinition( name="Shutdown", description="Shutdown the client")
	@ThingworxServiceResult( name=CommonPropertyNames.PROP_RESULT, description="", baseType="NOTHING")
	public synchronized void Shutdown() throws Exception {
		// Should not have to do this, but guard against this method being called more than once.
		if(this._shutdownThread == null) {
			// Create a thread for shutting down and start the thread
			this._shutdownThread = new Thread(this);
			this._shutdownThread.start();
		}
	}

	@Override
	public void run() {
		try {
			// Delay for a period to verify that the Shutdown service will return
			Thread.sleep(1000);
			// Shutdown the client
			this.getClient().shutdown();
		} catch (Exception x) {
			// Not much can be done if there is an exception here
			// In the case of production code should at least log the error
		}
	}
}
