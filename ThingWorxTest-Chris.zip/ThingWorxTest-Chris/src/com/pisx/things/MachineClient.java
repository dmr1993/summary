package com.pisx.things;
import com.thingworx.communications.client.ClientConfigurator;
import com.thingworx.communications.client.ConnectedThingClient;
import com.thingworx.communications.client.things.VirtualThing;
import com.thingworx.communications.common.SecurityClaims;

//for a detailed explanation of this example's operation 
public class MachineClient extends ConnectedThingClient {
	public final static String URI = "ws://localhost:80/Thingworx/WS";
	public final static String APP_KEY = "0d683290-73b7-4cd3-8a52-89df392b6472";
	public final static String SCAN_RATE = "5000";
	public final static String START_SENSOR = "0";
	public final static String SENSOR_NUMBER = "10";
	
	public MachineClient(ClientConfigurator config) throws Exception {
		super(config);
	}
	
	// Test example
	public static void main(String[] args) throws Exception {
		/*if(args.length < 3) {
			System.out.println("Required arguments not found!");
			System.out.println("URI AppKey ScanRate <StartSensor> <Number Of Sensors>");
			System.out.println("Example:");
			System.out.println("ws://localhost:80/Thingworx/WS xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx 1000 1 10");
			return;
		}*/
		
		// Set the required configuration information
		ClientConfigurator config = new ClientConfigurator();
		// The uri for connecting to Thingworx
		config.setUri(URI);
		// Reconnect every 15 seconds if a disconnect occurs or if initial connection cannot be made
		config.setReconnectInterval(15);
		
		// Set the security using an Application Key
		String appKey = APP_KEY;
		SecurityClaims claims = SecurityClaims.fromAppKey(appKey);
		config.setSecurityClaims(claims);
		
		// Set the name of the client
		config.setName("MachineGateway");
		// This client is a SDK
		config.setAsSDKType();

		// Get the scan rate (milliseconds) that is specific to this example
		// The example will execute the processScanRequest of the VirtualThing
		// based on this scan rate
		int scanRate = Integer.parseInt(SCAN_RATE);

		int startSensor = 0;
		int nSensors = 2;
		
		startSensor = Integer.parseInt(START_SENSOR);
		nSensors = Integer.parseInt(SENSOR_NUMBER);
		
		// Create the client passing in the configuration from above
		MachineClient client = new MachineClient(config);

		for(int sensor=1;sensor <= nSensors; sensor++) {
			int sensorID = startSensor + sensor;
			MachineThing machine = new MachineThing("Machine" + sensorID,"PISX Machine #" + sensorID, "Machine" + sensorID, client);
			client.bindThing(machine);
		}
		
		try {
			// Start the client
			client.start();
		}catch(Exception eStart) {
			System.out.println("Initial Start Failed : " + eStart.getMessage());
		}
		
		// As long as the client has not been shutdown, continue
		while(!client.isShutdown()) {
			// Only process the Virtual Things if the client is connected
			if(client.isConnected()) {
				// Loop over all the Virtual Things and process them
				for(VirtualThing thing : client.getThings().values()) {
					try {
						thing.processScanRequest();
					}
					catch(Exception eProcessing) {
						System.out.println("Error Processing Scan Request for [" + thing.getName() + "] : " + eProcessing.getMessage());
					}
				}
			}
			// Suspend processing at the scan rate interval
			Thread.sleep(scanRate);
		}
	}
}
