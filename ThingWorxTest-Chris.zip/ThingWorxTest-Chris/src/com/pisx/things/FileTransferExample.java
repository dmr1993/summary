package com.pisx.things;

import java.util.HashMap;

import com.thingworx.communications.client.ClientConfigurator;
import com.thingworx.communications.client.ConnectedThingClient;
import com.thingworx.communications.client.things.filetransfer.FileTransferVirtualThing;
import com.thingworx.communications.common.SecurityClaims;

public class FileTransferExample {

	// Substitute your thing name here
	private static final String ThingName = "FileTransferExample";
	
	public static void main(String[] args) {
		
		// Create a client config
		ClientConfigurator config = new ClientConfigurator();

		// Basic configuration. See SimpleClient.java for additional info.
		config.setUri("wss://localhost:80/Thingworx/WS");		
		//config.setAppKey("b90a4d19-69e0-45e0-8167-a81aee54a1c0");		
		String appKey = "6cee0715-3718-46df-8717-1b557fa51b68";
		SecurityClaims claims = SecurityClaims.fromAppKey(appKey);
		config.setSecurityClaims(claims);
		config.ignoreSSLErrors(true);
	
		try {
			ConnectedThingClient client = new ConnectedThingClient(config);
			HashMap<String, String> vDirectories = new HashMap<String, String>();
			vDirectories.put("home", "C:\\test");
			FileTransferVirtualThing myThing = new FileTransferVirtualThing(ThingName, "File Transfer Example", client, vDirectories);

			// Add two virtual directories that will act as the root directories in this
			// application's virtual file system.
			

			client.bindThing(myThing);	
			client.start();
			
			while(!client.isShutdown()) {
				Thread.sleep(5000);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
