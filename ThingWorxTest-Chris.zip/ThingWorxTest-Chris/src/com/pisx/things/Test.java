package com.pisx.things;

import java.util.HashSet;
import java.util.Set;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> set1 = new HashSet<String>();
		set1.add("1");
		set1.add("2");
		//set1.add("3");
		Set<String> set2 = new HashSet<String>();
		set2.add("1");
		set2.add("2");
		set2.add("3");
		System.out.println("result : " + set1.equals(set2));
	}

}
