package com.pisx.things;

public class TestThread extends Thread {
	private TestBean bean;
	public TestThread(TestBean bean){
		this.bean = bean;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		bean.setTest1("test1111");
		bean.setTest2("test2222");
	}
	
}
