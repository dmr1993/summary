package com.pisx.things;

public class Tester {
	static TestBean bean = new TestBean() ;
	public static void main(String[] args){
        System.out.println("ִ�����߳�");      
        Thread mythread = new TestThread(bean);  
        mythread.start();  
        System.err.println("ִ�к��ӡbean : " + bean);
	}
}
