package com.pisx.things;

import java.io.File;
import java.util.Random;

import com.thingworx.communications.client.ConnectedThingClient;
import com.thingworx.communications.client.things.VirtualThing;
import com.thingworx.metadata.FieldDefinition;
import com.thingworx.metadata.annotations.ThingworxPropertyDefinition;
import com.thingworx.metadata.annotations.ThingworxPropertyDefinitions;
import com.thingworx.metadata.annotations.ThingworxServiceDefinition;
import com.thingworx.metadata.annotations.ThingworxServiceParameter;
import com.thingworx.metadata.annotations.ThingworxServiceResult;
import com.thingworx.metadata.collections.FieldDefinitionCollection;
import com.thingworx.types.BaseTypes;
import com.thingworx.types.InfoTable;
import com.thingworx.types.collections.AspectCollection;
import com.thingworx.types.collections.ValueCollection;
import com.thingworx.types.constants.CommonPropertyNames;

//Refer to the "Steam Sensor Example" section of the documentation
//for a detailed explanation of this example's operation 

// Property Definitions
@SuppressWarnings("serial")
@ThingworxPropertyDefinitions(properties = {
		/*@ThingworxPropertyDefinition(name="Pressure", description="Pressure", baseType="INTEGER", category="Status", aspects={"isReadOnly:true"}),
		@ThingworxPropertyDefinition(name="Flow", description="Flow", baseType="INTEGER", category="Status", aspects={"isReadOnly:true"}),*/
})

/*// Event Definitions
@ThingworxEventDefinitions(events = {
	@ThingworxEventDefinition(name="SteamSensorFault", description="Steam sensor fault", dataShape="SteamSensor.Fault", category="Faults", isInvocable=true, isPropertyEvent=false)
})
*/
// Steam Thing virtual thing class that simulates a Steam Sensor
public class WaterMeterThing extends VirtualThing implements Runnable {	
	public WaterMeterThing(String name, String description, String identifier, ConnectedThingClient client) {
		super(name,description,identifier,client);
		super.initializeFromAnnotations();
		
		try{
			//AspectCollection ac = AspectCollection.fromString("isReadOnly:true");  //ֻ��
			AspectCollection ac = AspectCollection.fromString("isPersistent:true;isReadOnly:true;isLogged:true");  //¼�����ݿ�
			for(int i = 0; i < 100; i++){
				defineProperty("Test_" + i, "Test_" + i, BaseTypes.INTEGER,  ac);
			}			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
		
		FieldDefinitionCollection testFields = new FieldDefinitionCollection();
		testFields.addFieldDefinition(new FieldDefinition("name", BaseTypes.STRING));
		testFields.addFieldDefinition(new FieldDefinition("age", BaseTypes.INTEGER));
		defineDataShapeDefinition("PEOPLE", testFields);
	}

	// From the VirtualThing class
	// This method will get called when a connect or reconnect happens
	// Need to send the values when this happens
	// This is more important for a solution that does not send its properties on a regular basis
	public void synchronizeState() {
		// Be sure to call the base class
		super.synchronizeState();
		// Send the property values to Thingworx when a synchronization is required
		super.syncProperties();
	}
	
	// The processScanRequest is called by the SteamSensorClient every scan cycle
	@Override
	public void processScanRequest() throws Exception {
		// Be sure to call the base classes scan request
		super.processScanRequest();
		// Execute the code for this simulation every scan
		this.scanDevice();
	}
	
	// Performs the logic for the steam sensor, occurs every scan cycle
	public void scanDevice() throws Exception {
		for(int i = 0; i < 100; i++){
			Random rand = new Random();
			int a = 100 + rand.nextInt(100);
			super.setProperty("Test_" + i, a);
		}
		/*Random rand = new Random();
		int a = 100 + rand.nextInt(100);  //NBUtil.getFlow();
*/		//int b = 100 + rand.nextInt(100);  //NBUtil.getPressure();
		
		// Set the property values
		//super.setProperty("Flow", a);
		//super.setProperty("Pressure", b);
		// Update the subscribed properties and events to send any updates to Thingworx
		// Without calling these methods, the property and event updates will not be sent
		// The numbers are timeouts in milliseconds.
		super.updateSubscribedProperties(15000);
		super.updateSubscribedEvents(60000);
	}
	
	@ThingworxServiceDefinition( name="remoteCreateFile", description="remote create file")
	@ThingworxServiceResult( name=CommonPropertyNames.PROP_RESULT, description="Result", baseType="STRING" )
	public String remoteCreateFile( 
			@ThingworxServiceParameter( name="name", description="name value", baseType="STRING" ) String name) throws Exception {
		System.out.println("------------------------------------------------------------------");
		File file = new File("C://" + name);
		file.createNewFile();		
		return file.getAbsolutePath();
	}
	
	@ThingworxServiceDefinition( name="birthday", description="birthday")
	@ThingworxServiceResult( name=CommonPropertyNames.PROP_RESULT, description="Result", 
									baseType="INFOTABLE", aspects={"dataShape:PEOPLE"})
	public InfoTable birthday(@ThingworxServiceParameter( name="infoTable", description="infoTable", 
			baseType="INFOTABLE", aspects={"dataShape:PEOPLE"}) InfoTable people) throws Exception {
		InfoTable result = new InfoTable(getDataShapeDefinition("PEOPLE"));
		for(int i = 0; i < people.getLength(); i++){
			ValueCollection aPeople = people.getRow(i);
			Integer age = (Integer)aPeople.getValue("age");
			int age1 = age + 1;
			System.out.println("age : " + age + " + 1 : " + age1);			
			aPeople.SetIntegerValue("age", age1);
			result.addRow(aPeople);
		}		
		return result;
	}

	@ThingworxServiceDefinition( name="GetBigString", description="Get big string")
	@ThingworxServiceResult( name=CommonPropertyNames.PROP_RESULT, description="Result", baseType="STRING" )
	public String GetBigString() {
		StringBuilder sbValue = new StringBuilder();
		for(int i=0;i<24000;i++) {
			sbValue.append('0');
		}		
		return sbValue.toString();
	}



	@Override
	public void run() {
		try {
			// Delay for a period to verify that the Shutdown service will return
			Thread.sleep(1000);
			// Shutdown the client
			this.getClient().shutdown();
		} catch (Exception x) {
			// Not much can be done if there is an exception here
			// In the case of production code should at least log the error
		}
	}
}
