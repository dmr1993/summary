package com.pisx.things;
import java.io.File;
import java.util.HashMap;
import java.util.Random;


import com.thingworx.communications.client.ConnectedThingClient;
import com.thingworx.communications.client.things.VirtualThing;
import com.thingworx.communications.client.things.filetransfer.FileTransferVirtualThing;
import com.thingworx.metadata.annotations.ThingworxPropertyDefinition;
import com.thingworx.metadata.annotations.ThingworxPropertyDefinitions;
import com.thingworx.metadata.annotations.ThingworxServiceDefinition;
import com.thingworx.metadata.annotations.ThingworxServiceParameter;
import com.thingworx.metadata.annotations.ThingworxServiceResult;
import com.thingworx.types.BaseTypes;
import com.thingworx.types.constants.CommonPropertyNames;

//Refer to the "Steam Sensor Example" section of the documentation
//for a detailed explanation of this example's operation 

// Property Definitions
@SuppressWarnings("serial")
@ThingworxPropertyDefinitions(properties = {
		@ThingworxPropertyDefinition(name="����ת��", description="����ת��", baseType="NUMBER", category="Status", aspects={"isReadOnly:true"}),
		@ThingworxPropertyDefinition(name="����ת��", description="����ת��", baseType="NUMBER", category="Status", aspects={"isReadOnly:true"}),
		@ThingworxPropertyDefinition(name="ë������", description="ë������", baseType="INTEGER", category="Status", aspects={"isReadOnly:true"}),
		@ThingworxPropertyDefinition(name="�豸����", description="�豸����", baseType="INTEGER", category="Status", aspects={"isReadOnly:true"}),
		@ThingworxPropertyDefinition(name="���Ḻ��", description="���Ḻ��", baseType="NUMBER", category="Status", aspects={"isReadOnly:true"}),
		@ThingworxPropertyDefinition(name="��ǰ����", description="��ǰ����", baseType="STRING", category="Status", aspects={"isReadOnly:true"}),
		@ThingworxPropertyDefinition(name="���ᱶ��", description="���ᱶ��", baseType="NUMBER", category="Status", aspects={"isReadOnly:true"}),
		@ThingworxPropertyDefinition(name="�����ͺ�", description="�����ͺ�", baseType="STRING", category="Status", aspects={"isReadOnly:true"}),
		@ThingworxPropertyDefinition(name="�о��ͺ�", description="�о��ͺ�", baseType="STRING", category="Status", aspects={"isReadOnly:true"}),
		@ThingworxPropertyDefinition(name="��ǰ����", description="��ǰ����", baseType="STRING", category="Status", aspects={"isReadOnly:true"}),
})

// Event Definitions
/*@ThingworxEventDefinitions(events = {
	@ThingworxEventDefinition(name="SteamSensorFault", description="Steam sensor fault", dataShape="SteamSensor.Fault", category="Faults", isInvocable=true, isPropertyEvent=false)
})*/

// Steam Thing virtual thing class that simulates a Steam Sensor
public class RemoteFileThing extends FileTransferVirtualThing implements Runnable {
	
	//private double _totalFlow = 0.0;
	private Thread _shutdownThread = null;
	
	public RemoteFileThing(String name, String description, String identifier,  ConnectedThingClient client, HashMap<String, String> virtualDirectories) {
		super(name,description,client, virtualDirectories);
		super.setIdentifier(identifier);
		// Data Shape definition that is used by the steam sensor fault event
		// The event only has one field, the message
		/*FieldDefinitionCollection faultFields = new FieldDefinitionCollection();
		faultFields.addFieldDefinition(new FieldDefinition(CommonPropertyNames.PROP_MESSAGE,BaseTypes.STRING));
		defineDataShapeDefinition("SteamSensor.Fault", faultFields);*/
		// Populate the thing shape with the properties, services, and events that are annotated in this code
		super.initializeFromAnnotations();
	}

	// From the VirtualThing class
	// This method will get called when a connect or reconnect happens
	// Need to send the values when this happens
	// This is more important for a solution that does not send its properties on a regular basis
	public void synchronizeState() {
		// Be sure to call the base class
		super.synchronizeState();
		// Send the property values to Thingworx when a synchronization is required
		super.syncProperties();
		
	}
	
	// The processScanRequest is called by the SteamSensorClient every scan cycle
	@Override
	public void processScanRequest() throws Exception {
		// Be sure to call the base classes scan request
		super.processScanRequest();
		// Execute the code for this simulation every scan
		this.scanDevice();
	}
	
	// Performs the logic for the steam sensor, occurs every scan cycle
	public void scanDevice() throws Exception {
		// Set the Temperature property value in the range of 400-440
		Random rand = new Random();
		int prop1 = 17000 + rand.nextInt(1000); //����16000-17000���ڵ������
		int prop2 = 16000 + rand.nextInt(1000); //����16000-17000���ڵ������		
		int prop3 = 1000 + rand.nextInt(1000); //����1000-2000���ڵ������		
		int prop4 = rand.nextInt(100); //����0-100���ڵ������
		int prop5 = rand.nextInt(100); //����0-100���ڵ������
		
		// Set the property values
		super.setProperty("����ת��", prop1);
		super.setProperty("����ת��", prop2);
		super.setProperty("ë������", prop3);
		super.setProperty("���Ḻ��", prop4);
		super.setProperty("���ᱶ��", prop5);
		super.setProperty("�豸����", 786);
		super.setProperty("��ǰ����", "O1923");
		super.setProperty("�о��ͺ�", "X90");
		super.setProperty("�����ͺ�", "D9013");
		super.setProperty("��ǰ����", "����");
		// Update the subscribed properties and events to send any updates to Thingworx
		// Without calling these methods, the property and event updates will not be sent
		// The numbers are timeouts in milliseconds.
		super.updateSubscribedProperties(15000);
		super.updateSubscribedEvents(60000);
	}
	
	@ThingworxServiceDefinition( name="AddNumbers", description="Add Two Numbers")
	@ThingworxServiceResult( name=CommonPropertyNames.PROP_RESULT, description="Result", baseType="NUMBER" )
	public Double AddNumbers( 
			@ThingworxServiceParameter( name="a", description="Value 1", baseType="NUMBER" ) Double a,
			@ThingworxServiceParameter( name="b", description="Value 2", baseType="NUMBER" ) Double b) throws Exception {
		System.out.println("AddNumbers(a + b) = " + (a+b));		
		return a + b;
	}
	
	/*@ThingworxServiceDefinition( name="GetBigString", description="Get big string")
	@ThingworxServiceResult( name=CommonPropertyNames.PROP_RESULT, description="Result", baseType="STRING" )
	public String GetBigString() {
		StringBuilder sbValue = new StringBuilder();
		
		for(int i=0;i<24000;i++) {
			sbValue.append('0');
		}
		
		return sbValue.toString();
	}*/

	@ThingworxServiceDefinition( name="Shutdown", description="Shutdown the client")
	@ThingworxServiceResult( name=CommonPropertyNames.PROP_RESULT, description="", baseType="NOTHING")
	public synchronized void Shutdown() throws Exception {
		// Should not have to do this, but guard against this method being called more than once.
		if(this._shutdownThread == null) {
			// Create a thread for shutting down and start the thread
			this._shutdownThread = new Thread(this);
			this._shutdownThread.start();
		}
	}

	@Override
	public void run() {
		try {
			// Delay for a period to verify that the Shutdown service will return
			Thread.sleep(1000);
			// Shutdown the client
			this.getClient().shutdown();
		} catch (Exception x) {
			// Not much can be done if there is an exception here
			// In the case of production code should at least log the error
		}
	}
}
